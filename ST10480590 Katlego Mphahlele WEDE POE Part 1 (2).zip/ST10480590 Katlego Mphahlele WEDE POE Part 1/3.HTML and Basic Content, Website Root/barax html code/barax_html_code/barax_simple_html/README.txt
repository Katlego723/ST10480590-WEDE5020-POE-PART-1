BARAX CLOTHING - SIMPLE HTML WEBSITE

Pages included:
- index.html
- about.html
- products.html
- enquiry.html
- contact.html

Open index.html in a web browser to start the website.
Open the folder in Visual Studio Code to edit the files.
